# VideoFrameSplitter

The **VideoFrameSplitter** class provides a convenient way to split frames from a video file and save them as images using the OpenCV library. This class allows you to extract frames from a video and save them individually, which can be useful for various applications such as video analysis, computer vision tasks, and more.

## Usage

1. **Installation**: Ensure you have OpenCV and Python 3.x installed. If not, you can install OpenCV using the following command:
   ```sh
   pip install -r requirements.txt
   ```

2. **Import the Class**: Import the VideoFrameSplitter class into your Python script:
   ```python
   import cv2

   class VideoFrameSplitter:
       # ... class definition ...

   video_path = "input_video.mp4"
   output_folder = "output_frames/"

   frame_splitter = VideoFrameSplitter(video_path, output_folder)
   frame_splitter.split_frames(num_frames=10, evenly_sample=True)
   ```

3. **Provide Input and Output Paths**: Update the `video_path` and `output_folder` variables with the appropriate paths for your video and desired output folder.

4. **Configure Splitting Parameters**: Customize the splitting process by adjusting the `num_frames`, `evenly_sample`, and `interval` parameters in the `split_frames` function.

5. **Run the Script**: Execute your script, and the VideoFrameSplitter class will split the video frames and save them as images in the specified output folder.

## Class Parameters

- **video_path** (str): Path to the input video file.
- **output_folder** (str): Path to the folder where frames will be saved.
- **frame_prefix** (str, optional): Prefix for frame image filenames (default: "frame_").
- **image_format** (str, optional): Image format for saving frames (default: "png").

## Example

Here's an example of using the VideoFrameSplitter class:

```python
import cv2

video_path = "input_video.mp4"
output_folder = "output_frames/"

frame_splitter = VideoFrameSplitter(video_path, output_folder)
frame_splitter.split_frames(num_frames=10, evenly_sample=True)
```

In this example, the VideoFrameSplitter class is used to split frames from "input_video.mp4" and save them as images in the "output_frames/" folder.

## Note

This class uses OpenCV to read video frames, extract specified frames, and save them as images. It supports both evenly sampled frames and frames sampled at a specified interval.

## Contact Information

For questions or feedback about the VideoFrameSplitter class, you can reach out to the author, Iágson Carlos Lima Silva, on GitHub: [@iagsoncarlos](https://github.com/iagsoncarlos).
