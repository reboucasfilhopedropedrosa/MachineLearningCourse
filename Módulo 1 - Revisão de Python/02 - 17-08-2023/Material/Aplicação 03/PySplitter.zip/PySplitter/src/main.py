#!/usr/bin/python3
# -*- coding: UTF-8 -*-

# Created by Iágson Carlos Lima Silva on Tuesday, August 15, 2023.
# Copyright (c) 2023 @iagsoncarlos. All rights reserved.

__author__      = 'Iágson Carlos Lima Silva'
__copyright__   = 'Copyright (c) 2023 @iagsoncarlos'


from core.video_splitter import VideoFrameSplitter


if __name__ == "__main__":
    # ---------------------------------------------------------------------------------------------------
    # # splitter = VideoFrameSplitter(video_path, output_folder, frame_prefix, image_format)
    video_path = "input_video.mp4"
    output_folder = "frames_output"
    # frame_prefix = "frame_"  # Optional: Change the prefix of the saved frames
    # image_format = "png"     # Optional: Change the image format (e.g., png)
    # ---------------------------------------------------------------------------------------------------
    # # splitter.split_frames(num_frames, evenly_sample, interval)
    num_frames = 5             # Optional: Specify the number of frames to capture
    # evenly_sample = False    # Optional: Whether to evenly sample frames or use a specific interval
    # interval = 50            # Optional: Frame interval (used if evenly_sample is False)
    # ---------------------------------------------------------------------------------------------------

    splitter = VideoFrameSplitter(video_path, output_folder)

    splitter.split_frames(num_frames=num_frames)