#!/usr/bin/python3
# -*- coding: UTF-8 -*-

# Created by Iágson Carlos Lima Silva on Tuesday, August 15, 2023.
# Copyright (c) 2023 @iagsoncarlos. All rights reserved.

__author__      = 'Iágson Carlos Lima Silva'
__copyright__   = 'Copyright (c) 2023 @iagsoncarlos'

import os
import cv2


class VideoFrameSplitter:
    """
    A class for splitting frames from a video file and saving them as images.

    Attributes:
        video_path (str): Path to the input video file.
        output_folder (str): Path to the folder where frames will be saved.
        frame_prefix (str, optional): Prefix for frame image filenames. Default is "frame_".
        image_format (str, optional): Image format for saving frames. Default is "png".
    """
    def __init__(self, video_path, output_folder, frame_prefix="frame_", image_format="png"):
        """
        Initializes a VideoFrameSplitter instance.

        Args:
            video_path (str): Path to the input video file.
            output_folder (str): Path to the folder where frames will be saved.
            frame_prefix (str, optional): Prefix for frame image filenames. Default is "frame_".
            image_format (str, optional): Image format for saving frames. Default is "png".
        """
        self.video_path = video_path
        self.output_folder = output_folder
        self.frame_prefix = frame_prefix
        self.image_format = image_format

        # Create the output folder if it doesn't exist
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

    def split_frames(self, num_frames=None, evenly_sample=True, interval=1):
        """
        Split frames from the video and save them as images.

        Args:
            num_frames (int, optional): Number of frames to capture. Default is None.
            evenly_sample (bool, optional): Whether to evenly sample frames or use a specific interval.
                                           Default is True.
            interval (int, optional): Frame interval (used if evenly_sample is False). Default is 1.
        """
        cap = cv2.VideoCapture(self.video_path)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        if num_frames is None:
            num_frames = total_frames

        if num_frames > total_frames:
            num_frames = total_frames

        frame_numbers = []

        if evenly_sample:
            frame_indices = [int(i * total_frames / (num_frames - 1)) for i in range(num_frames)]
            frame_numbers = [frame_idx for frame_idx in frame_indices if frame_idx < total_frames]
        else:
            frame_numbers = [int(i * interval) for i in range(num_frames) if int(i * interval) < total_frames]

        frame_number = 0

        for idx in frame_numbers:
            cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ret, frame = cap.read()

            if not ret:
                break

            frame_filename = f"{self.frame_prefix}{frame_number:04d}.{self.image_format}"
            frame_path = os.path.join(self.output_folder, frame_filename)

            cv2.imwrite(frame_path, frame)
            print(f"[INFO] Saved frame {frame_number} as {frame_filename}")

            frame_number += 1

        cap.release()
        print("[INFO] Frame splitting completed.")

