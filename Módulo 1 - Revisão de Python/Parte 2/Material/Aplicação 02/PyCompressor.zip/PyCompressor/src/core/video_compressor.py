#!/usr/bin/python3
# -*- coding: UTF-8 -*-

# Created by Iágson Carlos Lima Silva on Tuesday, August 15, 2023.
# Copyright (c) 2023 @iagsoncarlos. All rights reserved.

__author__      = 'Iágson Carlos Lima Silva'
__copyright__   = 'Copyright (c) 2023 @iagsoncarlos'

import cv2


class VideoCompressor:
    """
    A class for compressing videos using OpenCV.

    Parameters:
    - input_path (str): Path to the input video file.
    - output_path (str): Path to the compressed output video file.
    - compression_quality (int, optional): JPEG compression quality (0 to 100).
      Lower values result in higher compression and lower quality.

    Example usage:
    input_video = "input_video.mp4"
    output_video = "compressed_video.mp4"
    compression_quality = 50  # Adjust this value to set the desired compression level

    compressor = VideoCompressor(input_video, output_video, compression_quality)
    compressor.compress()
    """

    def __init__(self, input_path, output_path, compression_quality=None):
        """
        Initialize the VideoCompressor object.

        Args:
        - input_path (str): Path to the input video file.
        - output_path (str): Path to the compressed output video file.
        - compression_quality (int, optional): JPEG compression quality (0 to 100).
        """
        self.input_path = input_path
        self.output_path = output_path
        self.compression_quality = compression_quality

    def compress(self):
        """
        Compresses the input video using specified compression quality.

        The compression process involves reading frames from the input video, applying
        JPEG compression to each frame, and writing the compressed frames to the output video.
        """
        cap = cv2.VideoCapture(self.input_path)
        if not cap.isOpened():
            raise Exception("[INFO] Error opening video file")

        frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = int(cap.get(cv2.CAP_PROP_FPS))
        fourcc = cv2.VideoWriter_fourcc(*'avc1')
        output = cv2.VideoWriter(self.output_path, fourcc, fps, (frame_width, frame_height), isColor=True)

        print("[INFO] Compression started...")

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        for current_frame in range(1, total_frames + 1):
            ret, frame = cap.read()

            if not ret:
                break

            print(f"[INFO] Compressing frame {current_frame}/{total_frames}")

            if self.compression_quality:
                success, compressed_frame = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, self.compression_quality])

                if success:
                    decompressed_frame = cv2.imdecode(compressed_frame, 1)
                    output.write(decompressed_frame)
                else:
                    break

        cap.release()
        output.release()

        print("[INFO] Video compression complete.")
