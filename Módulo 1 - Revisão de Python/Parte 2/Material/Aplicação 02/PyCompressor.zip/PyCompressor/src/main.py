#!/usr/bin/python3
# -*- coding: UTF-8 -*-

# Created by Iágson Carlos Lima Silva on Tuesday, August 15, 2023.
# Copyright (c) 2023 @iagsoncarlos. All rights reserved.

__author__      = 'Iágson Carlos Lima Silva'
__copyright__   = 'Copyright (c) 2023 @iagsoncarlos'


from core.video_compressor import VideoCompressor


if __name__ == "__main__":
    
    input_video = "input_video.mp4"
    output_video = "compressed_video.mp4"
    compression_quality = 50  # Adjust this value to set the desired compression level

    compressor = VideoCompressor(input_video, output_video, compression_quality)
    compressor.compress()
