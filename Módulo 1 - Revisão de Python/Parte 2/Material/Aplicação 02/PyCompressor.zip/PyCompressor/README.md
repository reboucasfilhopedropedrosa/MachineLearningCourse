# VideoCompressor

The **VideoCompressor** class offers a straightforward way to compress videos using the OpenCV library. This class provides an efficient method to reduce the size of video files while adjusting the compression quality to meet your requirements.

## Usage

1. **Installation**: Make sure you have OpenCV and Python 3.x installed. If not, you can install OpenCV using the following command:
   ```sh
   pip install -r requirements.txt
   ```

2. **Import the Class**: To use the VideoCompressor class, import it into your Python script:
   ```python
   import cv2

   class VideoCompressor:
       # ... class definition ...

   input_video = "input_video.mp4"
   output_video = "compressed_video.mp4"
   compression_quality = 50  # Adjust this value to set the desired compression level

   compressor = VideoCompressor(input_video, output_video, compression_quality)
   compressor.compress()
   ```

3. **Provide Input and Output Paths**: Update the `input_video` and `output_video` variables with the appropriate file paths for your video files.

4. **Set Compression Quality**: Adjust the `compression_quality` value to your desired level. A higher value will result in better quality but larger file size.

5. **Run the Script**: Run your script, and the VideoCompressor class will compress the input video according to your specified compression quality.

## Class Parameters

- **input_path** (str): Path to the input video file.
- **output_path** (str): Path to the compressed output video file.
- **compression_quality** (int, optional): JPEG compression quality (0 to 100). Lower values result in higher compression and lower quality.

## Example

Here's an example of using the VideoCompressor class:

```python
import cv2

input_video = "input_video.mp4"
output_video = "compressed_video.mp4"
compression_quality = 50  # Adjust this value to set the desired compression level

compressor = VideoCompressor(input_video, output_video, compression_quality)
compressor.compress()
```

In this example, the VideoCompressor class is used to compress a video named "input_video.mp4" into "compressed_video.mp4" with a compression quality of 50.

## Note

This class uses OpenCV to compress videos using JPEG compression. It reads frames from the input video, applies compression, and writes the compressed frames to the output video. The compression process might result in a trade-off between file size and video quality.

## Contact Information

For questions or feedback about the VideoCompressor class, you can reach out to the author, Iágson Carlos Lima Silva, on GitHub: [@iagsoncarlos](https://github.com/iagsoncarlos).