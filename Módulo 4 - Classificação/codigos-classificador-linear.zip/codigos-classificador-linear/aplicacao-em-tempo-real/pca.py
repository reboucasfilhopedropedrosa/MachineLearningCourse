# import idx2numpy
import numpy as np

class PCA:
    '''
        Implementação do Perceptron Logistico multiclasses
    '''
    
    def __init__(self, percentage_var=0.95):
        self.percentage_var = percentage_var
        self.Vq = None

    def pca(self, X):
        N = X.shape[0]

        # Normalização dos dados
        mean_X = np.mean(X, axis=0)
        std_X = np.std(X, axis=0)
        std_X[std_X == 0] = 1e-8  # Evitar divisão por zero
        X_centered = X - mean_X
        X_normalized = (X_centered) / std_X

        # Cálculo da matriz de covariância
        Cx = np.dot(X_normalized.T, X_normalized) / N
        
        # Autovalores e Autovetores
        # TODO - testar a decomposição em valores singulares (SVD).

        eigenvalues, eigenvectors = np.linalg.eig(Cx)

        # Ordenando os autovalores do maior para o menor
        idx = eigenvalues.argsort()[::-1]
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]

        # Determinando os q maiores autovalores que explicam uma porcentagem escolhida dos dados originais
        explained_variance = np.cumsum(eigenvalues) / np.sum(eigenvalues)

        # Número de componentes principais que preservam a informação
        num_components = np.sum(explained_variance <= self.percentage_var)
        # num_components = np.argmax(explained_variance >= self.percentage_var)

        # Matriz com os q primeiros autovetores
        self.Vq = eigenvectors[:, :num_components]

        # Dados transformados
        Z = np.dot(X_normalized, self.Vq) # X_centered @ self.Vq

        # Reconstroi os dados de entrada
        # Xr = Vq @ Z + np.mean(X, axis=1, keepdims=True)

        return Z
    
    def transform(self, X):
        # Aplicar a transformação PCA aos dados

        # Normalização dos dados
        mean_X = np.mean(X, axis=0)
        std_X = np.std(X, axis=0)
        std_X[std_X == 0] = 1e-8  # Evitar divisão por zero
        X_centered = X - mean_X
        X_normalized = (X_centered) / std_X

        Z = np.dot(X_normalized, self.Vq)
        
        return Z