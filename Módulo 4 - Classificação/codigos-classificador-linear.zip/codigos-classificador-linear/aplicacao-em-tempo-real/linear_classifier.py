import numpy as np

class LinearClassifier:
    def __init__(self):
        self.W = None
        self.formule = None # y = W^T * x
        self.array_X = None
        self.array_y = None
    
    def fit(self, X, y, num_classes):
        X = np.array(X)
        y = np.array(y)
        self.array_X = X
        self.array_y = y
        
        # # Transforma as imagens em vetores unidimensionais
        # X_flat = X.reshape(X.shape[0], -1)
        
        # Adiciona uma coluna de 1's para o termo de viés
        X_with_bias = np.column_stack((X, np.ones(X.shape[0])))
        
        # Codifica as classes no formato one-hot
        # FIXME: adaptando a formulação matematica para uma parecida com o exemplo dado em sala
        y_one_hot = np.zeros((len(y), num_classes))
        for i, label in enumerate(y):
            y_one_hot[i, label] = 1
            
        # Calcula a pseudo-inversa de X_with_bias e
        # Calcula os coeficientes usando mínimos quadrados
        self.W = np.linalg.pinv(X_with_bias) @ y_one_hot

        # A função linear é definida como a combinação linear dos atributos
        self.formule = lambda x: np.dot(np.append(x, 1), self.W)

    def predict(self, x):
        result = list()
        for valor in x:
            prediction = self.formule(valor)

            normalized_prediction = self.softmax_stable(prediction)
            result.append(np.argmax(normalized_prediction))
        
        return np.array(result)

    def predict_real_time(self, x):
        result = list()
        prediction = np.dot(np.append(x, 1), self.W)

        normalized_prediction = self.softmax_stable(prediction)
        result.append(np.argmax(normalized_prediction))
    
        return np.array(result)
  
    def softmax_stable(self, x):
        return(np.exp(x - np.max(x)) / np.exp(x - np.max(x)).sum())

    def softmax(self, x):
        return(np.exp(x)/np.exp(x).sum())