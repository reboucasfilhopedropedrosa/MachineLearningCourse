import datetime
import numpy as np

class LogisticPerceptron:
    '''
        Implementação do Perceptron Logistico multiclasses
    '''
    
    def __init__(self, X_train=None, Y_train=None, X_val=None, Y_val=None, save_predictions=True, epochs=100, learning_rate=0.01, moment_factor=0.9, verbose=False) -> None:
        self.verbose = verbose
        
        self.epochs = epochs
        self.learning_rate = learning_rate
        self.moment_factor = moment_factor
        
        self.X_train = X_train
        self.Y_train = Y_train
        self.X_val = X_val
        self.Y_val = Y_val
        
        self.save_predictions = save_predictions
        self.predictions_matrix = list()
        
        self.num_classes = len(np.unique(Y_train))
        
        num_features = self.X_train.shape[1]
        
        self.weights = np.zeros((num_features, self.num_classes))
        self.bias = np.zeros((self.num_classes, 1))
        
        # Inicializando os momentos para cada camada
        self.moment = np.zeros_like(self.weights)
        self.moment_bias = np.zeros_like(self.bias)
        
    def activate_function(self, Z, type='sigmoid'):
        '''
            Função que calcula a ativação do neuronio.
                FIXME - Os valores sao normalizados entre 0 e 1
                FIXME - Sao 10 classes (0 ate 9), logo essa função retorna um
                        vetor de tamanho 1x10 ([1. 0. 0. 0. 0. 0. 0. 0. 0. 0.] -> exemplo do numero 0)
            Argumentos de entrada:
                Z -> matriz de dados de entrada 
                type -> pode ser sigmoid ou tanh (padrao é sigmoid)
        '''
        
        if type=='sigmoid':
            return 1 / (1 + np.exp(-Z))
        if type=='softmax':
            exp_Z = np.exp(Z - np.max(Z, axis=1, keepdims=True))
            return exp_Z / np.sum(exp_Z, axis=1, keepdims=True)    
        if type=='tanh':
            return np.tanh(Z) # tangente hiperbólica
    
    def compute_loss(self, y_true, y_pred):
        return np.mean((y_true - y_pred)**2)
        
    def fit(self, early_stopping_patience=10, update_top_n=1):
        '''
            Função de treinamento do perceptron logistico, baseado em N classes
        '''
        
        # Transformando os rótulos em vetores one-hot para cada classe
        y_one_hot = np.zeros((len(self.Y_train), self.num_classes))
        for i, label in enumerate(self.Y_train):
            y_one_hot[i, label] = 1

        best_val_loss = float('inf')
        patience = 0
        loss_weight_pairs = []
        for epoch in range(1, self.epochs+1):
            Z = np.dot(self.X_train, self.weights) + self.bias.T
            pred = self.activate_function(Z, type='softmax')

            error = pred - y_one_hot

            self.weights -= self.moment_factor * self.moment + self.learning_rate * np.dot(self.X_train.T, error)
            self.bias -= self.moment_factor * self.moment_bias + self.learning_rate * np.sum(error, axis=0, keepdims=True).T
            
            train_loss = self.compute_loss(y_one_hot, pred)

            loss_weight_pairs.append((train_loss, self.weights.copy()))  
            
            if epoch % 50 == 0:
                loss = self.compute_loss(y_one_hot, pred)
                
                # Checagem de convergencia do treinamento
                if self.X_val is not None and self.Y_val is not None:
                    patience = self.early_stopping(best_val_loss)

                    if patience >= early_stopping_patience:
                        print(f'Early stopping at epoch {epoch} due to no improvement in validation loss.')
                        break
                
                # Fazer previsões nos dados de validação
                predictions = self.predict(self.X_val)
                
                # Avaliação do desempenho do modelo
                accuracy = np.mean(predictions == self.Y_val)

                if self.verbose:
                    print(f'[TREINAMENTO] - Epoca {epoch} - Loss: {loss} - Predições: {predictions} - Acurácia: {accuracy:.4f} - Taxa de Erro - {1 - accuracy:.4f} {datetime.datetime.now()}')

        loss_weight_pairs.sort(key=lambda x: x[0])
        for i in range(update_top_n):
            best_loss, weights = loss_weight_pairs[i]
            self.weights = weights

        # Fazer previsões nos dados de validação
        best_predictions = self.predict(self.X_val)
        
        # Avaliação do desempenho do modelo
        best_accuracy = np.mean(best_predictions == self.Y_val)

        if self.save_predictions:
            self.predictions_matrix.append(best_predictions)
                
        if self.verbose:
            print(f'[TREINAMENTO] - Melhor MSE Loss: {best_loss} - Melhor acurácia: {best_accuracy} - {datetime.datetime.now()}')
                    
    def early_stopping(self, best_val_loss):
        # Forward pass para calcular as ativações da camada oculta (hidden layer)
        Z_val = np.dot(self.X_val, self.weights) + self.bias.T
        pred_val = self.activate_function(Z_val, type='softmax')
        
        val_y_one_hot = np.zeros((len(self.Y_val), self.num_classes))
        val_y_one_hot[np.arange(len(self.Y_val)), self.Y_val.flatten()] = 1
        val_loss = self.compute_loss(val_y_one_hot, pred_val)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience = 0
        else:
            patience += 1
        
        return patience
            
    def predict(self, x):
        '''
            Função de inferencia para classificação de um novo dado e nos pessos obtidos na etapa de treinamento
        '''
        
        Z = np.dot(x, self.weights) + self.bias.T
        probabilities = self.activate_function(Z, type='softmax')
        
        return np.argmax(probabilities, axis=1)
