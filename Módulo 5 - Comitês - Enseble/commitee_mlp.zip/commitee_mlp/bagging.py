import numpy as np
import pandas as pd

from collections import Counter

class Bagging:
    # Função para contar ocorrências e obter a classe com maior votação
    def majority_vote(self, column):
        counts = np.bincount(column)
        return np.argmax(counts)
    
    def simple_average_vote(self, predictions):
        # class_sums = np.zeros(num_classes)
        predicts_array = np.array(predictions)

        # Criando o DataFrame a partir do array transposto
        df = pd.DataFrame(predicts_array.T, columns=[f"Model_{i+1}" for i in range(len(predictions))])
        
        # Calculando a média simples de voto do comitê
        final_predictions = df.mode(axis=1).iloc[:, 0]

        return np.array(final_predictions).astype(np.uint8)
    
    def cross_validation(self, dataset, dataset_labels, ratio=0.8):
        n_samples = len(dataset)
        n_sample_train = round(n_samples * ratio)

        indices = np.arange(n_samples)
        np.random.shuffle(indices)

        indices_train = indices[:n_sample_train]
        indices_validation = indices[n_sample_train:]

        sample_train = dataset[indices_train]
        sample_train_labels = dataset_labels[indices_train]

        sample_validation = dataset[indices_validation]
        sample_validation_labels = dataset_labels[indices_validation]

        return sample_train, sample_train_labels, sample_validation, sample_validation_labels

    
    # Create a random subsample from the dataset with replacement
    def subsample(self, dataset, dataset_labels, ratio=1.0):
        n_sample = round(len(dataset) * ratio)
        indices = np.random.choice(len(dataset), n_sample, replace=True)
        sample = dataset[indices]
        sample_labels = dataset_labels[indices]
        
        return sample, sample_labels
        