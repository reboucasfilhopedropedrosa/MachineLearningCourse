import datetime
import numpy as np

class MLP:
    def __init__(self, X=None, y=None, X_val=None, y_val=None, epochs=1000, learning_rate=0.9, momentum=0.9, num_neurons_hidden_layer=300, num_classes=None, verbose=False, seed=True, save_predictions=False) -> None:
        self.X = X
        self.y = y
        self.X_val = X_val
        self.y_val = y_val

        self.seed = seed
        self.epochs = epochs
        self.verbose = verbose
        self.learning_rate = learning_rate

        self.momentum = momentum
        self.save_predictions = save_predictions
        self.predictions_matrix = list()
        self.num_neurons_hidden_layer = num_neurons_hidden_layer
        
        num_features = self.X.shape[1]

        if num_classes is None:
            num_classes = len(np.unique(self.y))
            
        self.input_layer_W, self.bias_input_layer = self.init_layers(self.num_neurons_hidden_layer, num_features)
        self.output_layer_M, self.bias_output_layer = self.init_layers(num_classes, self.num_neurons_hidden_layer)

        # Inicializando os momentos para cada camada
        self.moment_input_W = np.zeros_like(self.input_layer_W)
        self.moment_output_M = np.zeros_like(self.output_layer_M)
        self.moment_bias_input = np.zeros_like(self.bias_input_layer)
        self.moment_bias_output = np.zeros_like(self.bias_output_layer)
        
    def activate_function(self, Z, type='sigmoid'):
        '''
        Função que calcula a ativação do neurônio.
        Argumentos de entrada:
            Z -> matriz de dados de entrada
            type -> pode ser sigmoid ou softmax (padrão é sigmoid)
        '''

        if type == 'sigmoid':
            return 1 / (1 + np.exp(-Z))
        elif type == 'softmax':
            exp_Z = np.exp(Z - np.max(Z, axis=1, keepdims=True))
            return exp_Z / np.sum(exp_Z, axis=1, keepdims=True)
        else:
            raise ValueError("Tipo de função de ativação inválido.")

    def init_layers(self, layerSize, prevLayerSize):
        if self.seed:
            np.random.seed(42)

        weights = np.random.randn(prevLayerSize, layerSize) * np.sqrt(2/prevLayerSize) # Inicialização de Xavier
        bias = np.random.randn(layerSize, 1) * 0.5

        return weights, bias

    def cross_entropy_loss(self, y_true, y_pred):
        '''
        Calcula a Cross-Entropy Loss para um único exemplo de treinamento.
        y_true: vetor one-hot com as classes verdadeiras (dimensão: num_classes,)
        y_pred: vetor de probabilidades previstas (dimensão: num_classes,)
        '''
        # Adiciona uma pequena quantidade para evitar log(0)
        epsilon = 1e-10
        y_pred = np.clip(y_pred, epsilon, 1.0)
        return -np.sum(y_true * np.log(y_pred))

    def compute_loss(self, y_true, y_pred, loss_type='mse'):
        '''
        Calcula a Cross-Entropy Loss média para o conjunto de treinamento.
        y_true: matriz de vetores one-hot com as classes verdadeiras (dimensão: n_samples x num_classes)
        y_pred: matriz de vetores de probabilidades previstas (dimensão: n_samples x num_classes)
        '''
        if loss_type == 'mse':
            return np.mean((y_true - y_pred)**2)
        if loss_type == 'cross-entropy':
            n_samples = y_true.shape[0]
            total_loss = np.sum([self.cross_entropy_loss(y_true[i], y_pred[i]) for i in range(n_samples)])
            return total_loss / n_samples

    def fit(self, num_classes=10, verbose=True, early_stopping_patience=25):
        '''
        Função de treinamento do Perceptron Logístico, baseado em N classes
        '''

        # Transformando os rótulos em vetores one-hot para cada classe
        y_one_hot = np.zeros((len(self.y), num_classes))
        y_one_hot[np.arange(len(self.y)), self.y.flatten()] = 1

        best_val_loss = float('inf')
        patience = 0

        for epoch in range(1, self.epochs+1):
            # Passo 1 - Forward
            Zh = np.dot(self.X, self.input_layer_W) + self.bias_input_layer.T
            pred_h = self.activate_function(Zh, type='sigmoid')

            Zo = np.dot(pred_h, self.output_layer_M) + self.bias_output_layer.T
            pred_o = self.activate_function(Zo, type='softmax')

            # Passo 2 - Backpropagation
            error_o = pred_o - y_one_hot

            # Gradiente local
            gradient_o = error_o / len(self.X)

            error_h = np.dot(gradient_o, self.output_layer_M.T)

            # Gradiente local
            gradient_h = error_h * pred_h * (1 - pred_h)

            # Atualizando os pesos e os bias da camada de saída
            self.moment_output_M = self.momentum * self.moment_output_M + self.learning_rate * np.dot(pred_h.T, gradient_o)
            self.moment_bias_output = self.momentum * self.moment_bias_output + self.learning_rate * np.sum(gradient_o, axis=0, keepdims=True).T
            self.moment_input_W = self.momentum * self.moment_input_W + self.learning_rate * np.dot(self.X.T, gradient_h)
            self.moment_bias_input = self.momentum * self.moment_bias_input + self.learning_rate * np.sum(gradient_h, axis=0, keepdims=True).T

            # Atualizando os pesos e os bias da camada de saída com o fator de momento
            self.output_layer_M -= self.moment_output_M
            self.bias_output_layer -= self.moment_bias_output

            # Atualizando os pesos e os bias da camada oculta com o fator de momento
            self.input_layer_W -= self.moment_input_W
            self.bias_input_layer -= self.moment_bias_input

            if epoch % 10 == 0:
                loss = self.compute_loss(y_one_hot, pred_o)
                
                # Early stopping check
                if self.X_val is not None and self.y_val is not None:
                    patience = self.early_stopping(best_val_loss, num_classes)

                    if patience >= early_stopping_patience:
                        print(f'Early stopping at epoch {epoch} due to no improvement in validation loss.')
                        break
                    
                    # Fazer previsões nos dados de validação
                    predictions = self.predict(self.X_val)
                    
                    # Avaliação do desempenho do modelo
                    accuracy = np.mean(predictions == self.y_val)
                    
                if self.verbose:
                    print(f'[TREINAMENTO] - Numero de neuronios: {self.num_neurons_hidden_layer} - Epoca {epoch} - Loss: {loss} - Predições: {predictions} - Acurácia: {accuracy:.4f} - Taxa de Erro - {1 - accuracy:.4f} {datetime.datetime.now()}')
        
        if self.save_predictions:
            self.predictions_matrix.append(predictions)
                    
        # Fazer previsões nos dados de validação
        best_predictions = self.predict(self.X_val)
        
        # Avaliação do desempenho do modelo
        best_accuracy = np.mean(best_predictions == self.y_val)

        if self.save_predictions:
            self.predictions_matrix.append(best_predictions)
                
        if self.verbose:
            print(f'[TREINAMENTO] - Melhor MSE Loss: {loss} - Melhor acurácia: {best_accuracy} - {datetime.datetime.now()}')
                         
    def early_stopping(self, best_val_loss, num_classes):
        # Forward pass para calcular as ativações da camada oculta (hidden layer)
        Zh_val = np.dot(self.X_val, self.input_layer_W) + self.bias_input_layer.T
        pred_h_val = self.activate_function(Zh_val, type='sigmoid')

        # Forward pass para calcular as ativações da camada de saída (output layer)
        Zo_val = np.dot(pred_h_val, self.output_layer_M) + self.bias_output_layer.T
        pred_o_val = self.activate_function(Zo_val, type='softmax')
        
        val_y_one_hot = np.zeros((len(self.y_val), num_classes))
        val_y_one_hot[np.arange(len(self.y_val)), self.y_val.flatten()] = 1
        val_loss = self.compute_loss(val_y_one_hot, pred_o_val)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience = 0
        else:
            patience += 1
        
        return patience
        
    def predict(self, x):
        '''
        Função de inferência para classificação de um novo dado usando os pesos obtidos na etapa de treinamento
        Argumentos de entrada:
            x: matriz de dados de entrada do novo dado (dimensões: n_samples x num_features)
        Retorna:
            predictions: vetor com as previsões de classe para cada amostra de entrada (dimensão: n_samples,)
        '''

        # Forward pass para calcular as ativações da camada oculta (hidden layer)
        Zh_val = np.dot(x, self.input_layer_W) + self.bias_input_layer.T
        pred_h_val = self.activate_function(Zh_val, type='sigmoid')

        # Forward pass para calcular as ativações da camada de saída (output layer)
        Zo_val = np.dot(pred_h_val, self.output_layer_M) + self.bias_output_layer.T
        pred_o_val = self.activate_function(Zo_val, type='softmax')
        
        # Obter as previsões finais, escolhendo a classe com maior probabilidade para cada amostra
        predictions = np.argmax(pred_o_val, axis=1)

        return predictions